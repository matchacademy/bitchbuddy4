/**
 * Utenti.gs — gestisce la scheda "Utenti".
 * Colonne attese: ID_Utente | Nome | Email | Password_Hash |
 *                 Telegram_Username | WhatsApp_Link | Privacy_Status
 *
 * NOTA SICUREZZA: se attivi il login con Google (consigliato),
 * non avrai bisogno di Password_Hash: usa Session.getActiveUser().getEmail()
 * per identificare l'utente e salta la verifica password qui sotto.
 * Vedi README.md → "Attivare il login reale con Google".
 */

function Utenti_register(body){
  const sheet = getSheet('Utenti');
  const utenti = sheetToObjects(sheet);

  const esiste = utenti.some(u => String(u.Email).toLowerCase() === String(body.email).toLowerCase());
  if(esiste) throw new Error('Esiste già un account con questa email.');

  const id = 'u_' + Utilities.getUuid().slice(0, 8);
  const passwordHash = Utilities.base64Encode(
    Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, body.password)
  );

  sheet.appendRow([id, body.nome, body.email, passwordHash, '', '', 'Pubblico']);

  // Email di verifica reale (facoltativa):
  // MailApp.sendEmail(body.email, 'Conferma il tuo account BitchBuddy', 'Link: ' + buildVerifyLink(id));

  return { id, nome: body.nome, email: body.email };
}

function Utenti_login(body){
  const sheet = getSheet('Utenti');
  const utenti = sheetToObjects(sheet);
  const passwordHash = Utilities.base64Encode(
    Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, body.password)
  );
  const utente = utenti.find(u =>
    String(u.Email).toLowerCase() === String(body.email).toLowerCase() &&
    u.Password_Hash === passwordHash
  );
  if(!utente) throw new Error('Email o password non corrette.');
  return utente;
}

function Utenti_update(body){
  const sheet = getSheet('Utenti');
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idCol = headers.indexOf('ID_Utente');

  for(let r = 1; r < values.length; r++){
    if(values[r][idCol] === body.id){
      const rowNum = r + 1;
      if(body.nome !== undefined) sheet.getRange(rowNum, headers.indexOf('Nome') + 1).setValue(body.nome);
      if(body.telegram !== undefined) sheet.getRange(rowNum, headers.indexOf('Telegram_Username') + 1).setValue(body.telegram);
      if(body.whatsapp !== undefined) sheet.getRange(rowNum, headers.indexOf('WhatsApp_Link') + 1).setValue(body.whatsapp);
      if(body.privacy !== undefined) sheet.getRange(rowNum, headers.indexOf('Privacy_Status') + 1).setValue(body.privacy);
      return { ok: true };
    }
  }
  throw new Error('Utente non trovato.');
}
