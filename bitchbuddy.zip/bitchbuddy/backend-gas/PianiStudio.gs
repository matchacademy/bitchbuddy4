/**
 * PianiStudio.gs — gestisce la scheda "Piani_Studio".
 * Colonne attese: ID_Record | ID_Utente | Materia | Stato |
 *                 Note | Data_Esame
 */

function PianiStudio_getByUser(idUtente){
  const sheet = getSheet('Piani_Studio');
  return sheetToObjects(sheet).filter(p => p.ID_Utente === idUtente);
}

function PianiStudio_add(body){
  const sheet = getSheet('Piani_Studio');
  const esistenti = sheetToObjects(sheet);
  const duplicato = esistenti.some(p => p.ID_Utente === body.idUtente && p.Materia === body.materia);
  if(duplicato) throw new Error('Hai già aggiunto questa materia.');

  const id = 'p_' + Utilities.getUuid().slice(0, 8);
  sheet.appendRow([id, body.idUtente, body.materia, 'Da preparare', body.note || '', body.dataEsame || '']);
  return { id };
}

function PianiStudio_update(body){
  const sheet = getSheet('Piani_Studio');
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idCol = headers.indexOf('ID_Record');

  for(let r = 1; r < values.length; r++){
    if(values[r][idCol] === body.id){
      const rowNum = r + 1;
      if(body.stato !== undefined) sheet.getRange(rowNum, headers.indexOf('Stato') + 1).setValue(body.stato);
      if(body.note !== undefined) sheet.getRange(rowNum, headers.indexOf('Note') + 1).setValue(body.note);
      if(body.dataEsame !== undefined) sheet.getRange(rowNum, headers.indexOf('Data_Esame') + 1).setValue(body.dataEsame);
      return { ok: true };
    }
  }
  throw new Error('Piano di studio non trovato.');
}

function PianiStudio_delete(body){
  const sheet = getSheet('Piani_Studio');
  const values = sheet.getDataRange().getValues();
  const idCol = values[0].indexOf('ID_Record');

  for(let r = 1; r < values.length; r++){
    if(values[r][idCol] === body.id){
      sheet.deleteRow(r + 1);
      return { ok: true };
    }
  }
  throw new Error('Piano di studio non trovato.');
}

/**
 * Restituisce i compagni che stanno preparando la stessa materia,
 * escludendo l'utente corrente e i profili impostati su "Privato".
 */
function PianiStudio_getCompagni(materia, idUtenteEscluso){
  const piani = sheetToObjects(getSheet('Piani_Studio')).filter(p => p.Materia === materia && p.ID_Utente !== idUtenteEscluso);
  const utenti = sheetToObjects(getSheet('Utenti'));

  return piani.map(p => {
    const u = utenti.find(x => x.ID_Utente === p.ID_Utente);
    if(!u || u.Privacy_Status === 'Privato') return null;
    return {
      id: u.ID_Utente, nome: u.Nome, telegram: u.Telegram_Username,
      whatsapp: u.WhatsApp_Link, stato: p.Stato, note: p.Note
    };
  }).filter(Boolean);
}
