/**
 * FAQ.gs — gestisce la scheda "Domande_FAQ".
 * Colonne attese: ID_Domanda | Materia | Testo_Domanda |
 *                 ID_Utente_Autore | Upvotes
 */

function FAQ_getByMateria(materia){
  return sheetToObjects(getSheet('Domande_FAQ'))
    .filter(f => f.Materia === materia)
    .sort((a, b) => Number(b.Upvotes) - Number(a.Upvotes));
}

function FAQ_add(body){
  const sheet = getSheet('Domande_FAQ');
  const id = 'f_' + Utilities.getUuid().slice(0, 8);
  sheet.appendRow([id, body.materia, body.testo, body.idUtenteAutore, 0]);
  return { id };
}

function FAQ_upvote(body){
  const sheet = getSheet('Domande_FAQ');
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idCol = headers.indexOf('ID_Domanda');
  const upvoteCol = headers.indexOf('Upvotes');

  for(let r = 1; r < values.length; r++){
    if(values[r][idCol] === body.id){
      const rowNum = r + 1;
      const nuovoValore = Number(values[r][upvoteCol]) + 1;
      sheet.getRange(rowNum, upvoteCol + 1).setValue(nuovoValore);
      return { upvotes: nuovoValore };
    }
  }
  throw new Error('Domanda non trovata.');
}
