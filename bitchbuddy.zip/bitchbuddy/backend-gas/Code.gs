/**
 * Code.gs — punto di ingresso della Web App.
 * -----------------------------------------------------------
 * Questo file NON contiene logica di business: si limita a
 * ricevere le richieste HTTP e instradarle verso il modulo
 * giusto (Utenti.gs, Catalogo.gs, PianiStudio.gs, FAQ.gs).
 *
 * Ogni azione arriva come parametro "action" in querystring
 * (GET) o nel corpo JSON (POST), così puoi sostituire un
 * singolo modulo senza toccare gli altri.
 *
 * Vedi README.md → "Collegare il backend reale" per i passi
 * di pubblicazione.
 */

const SHEET_ID = 'INCOLLA_QUI_ID_DEL_TUO_GOOGLE_SHEET';

function doGet(e){
  const action = e.parameter.action;
  try{
    switch(action){
      case 'getCatalogo': return jsonOutput(Catalogo_getAll());
      case 'getPianiByUser': return jsonOutput(PianiStudio_getByUser(e.parameter.idUtente));
      case 'getCompagniByMateria': return jsonOutput(PianiStudio_getCompagni(e.parameter.materia, e.parameter.idUtenteEscluso));
      case 'getFaqByMateria': return jsonOutput(FAQ_getByMateria(e.parameter.materia));
      default: return jsonOutput({ error: 'Azione GET non riconosciuta: ' + action });
    }
  }catch(err){
    return jsonOutput({ error: err.message });
  }
}

function doPost(e){
  const body = JSON.parse(e.postData.contents || '{}');
  const action = body.action;
  try{
    switch(action){
      case 'registerUser': return jsonOutput(Utenti_register(body));
      case 'loginUser': return jsonOutput(Utenti_login(body));
      case 'updateUser': return jsonOutput(Utenti_update(body));
      case 'addPiano': return jsonOutput(PianiStudio_add(body));
      case 'updatePiano': return jsonOutput(PianiStudio_update(body));
      case 'deletePiano': return jsonOutput(PianiStudio_delete(body));
      case 'addFaq': return jsonOutput(FAQ_add(body));
      case 'upvoteFaq': return jsonOutput(FAQ_upvote(body));
      default: return jsonOutput({ error: 'Azione POST non riconosciuta: ' + action });
    }
  }catch(err){
    return jsonOutput({ error: err.message });
  }
}

/** Helper condiviso: apre il foglio per nome scheda. */
function getSheet(nomeScheda){
  return SpreadsheetApp.openById(SHEET_ID).getSheetByName(nomeScheda);
}

/** Helper condiviso: converte l'output in JSON con i permessi CORS necessari. */
function jsonOutput(obj){
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/** Helper condiviso: legge tutte le righe di una scheda come array di oggetti. */
function sheetToObjects(sheet){
  const values = sheet.getDataRange().getValues();
  const headers = values.shift();
  return values.map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}
