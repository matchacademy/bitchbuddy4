/**
 * Catalogo.gs — gestisce la scheda "Catalogo_Accademico".
 * Colonne attese: ID_Corso | Nome_Corso | Materia | Professore
 *
 * Questa scheda è la fonte dei menu a cascata Corso → Materia →
 * Professore nella Dashboard. Aggiungere una riga qui basta per
 * far comparire un nuovo corso/materia/professore nel sito,
 * senza toccare il codice.
 */

function Catalogo_getAll(){
  const sheet = getSheet('Catalogo_Accademico');
  return sheetToObjects(sheet);
}
