/* ============================================================
   db.js
   -------------------------------------------------------------
   Livello di accesso ai dati. In questa DEMO i dati vivono nel
   localStorage del browser e simulano ESATTAMENTE le 4 schede
   Google Sheets descritte nel documento originale:

     1) Utenti
     2) Catalogo_Accademico
     3) Piani_Studio
     4) Domande_FAQ

   Quando vorrai collegare il backend reale (Google Apps Script +
   Google Sheets), questo è l'UNICO file da sostituire: le view
   (dashboard.js, materia.js, ecc.) chiamano solo le funzioni
   esposte da "DB", quindi non toccherai nient'altro.
   Vedi il README.md, sezione "Passare al backend reale".
   ============================================================ */

const DB_KEY = 'bitchbuddy_db_v1';
const SESSION_KEY = 'bitchbuddy_session_v1';

function uid(prefix){
  return prefix + '_' + Math.random().toString(36).slice(2, 9);
}

function seedDatabase(){
  return {
    utenti: [
      { id:'u_demo1', nome:'Giulia Romano', email:'giulia@demo.it', passwordHash:'demo', telegram:'@giulia_r', whatsapp:'', privacy:'Pubblico' },
      { id:'u_demo2', nome:'Marco Ferri', email:'marco@demo.it', passwordHash:'demo', telegram:'', whatsapp:'393331234567', privacy:'Pubblico' },
      { id:'u_demo3', nome:'Sara Conti', email:'sara@demo.it', passwordHash:'demo', telegram:'@sara.c', whatsapp:'393339876543', privacy:'Pubblico' }
    ],
    catalogo: [
      { idCorso:'c1', nomeCorso:'Economia Aziendale', materia:'Analisi Matematica I', professore:'Prof. Bianchi' },
      { idCorso:'c1', nomeCorso:'Economia Aziendale', materia:'Microeconomia', professore:'Prof.ssa Verdi' },
      { idCorso:'c1', nomeCorso:'Economia Aziendale', materia:'Statistica', professore:'Prof. Russo' },
      { idCorso:'c2', nomeCorso:'Ingegneria Informatica', materia:'Basi di Dati', professore:'Prof. Colombo' },
      { idCorso:'c2', nomeCorso:'Ingegneria Informatica', materia:'Sistemi Operativi', professore:'Prof.ssa Ferrari' },
      { idCorso:'c2', nomeCorso:'Ingegneria Informatica', materia:'Reti di Calcolatori', professore:'Prof. Greco' },
      { idCorso:'c3', nomeCorso:'Giurisprudenza', materia:'Diritto Privato', professore:'Prof. Marino' },
      { idCorso:'c3', nomeCorso:'Giurisprudenza', materia:'Diritto Costituzionale', professore:'Prof.ssa Villa' }
    ],
    pianiStudio: [
      { id:'p1', idUtente:'u_demo1', materia:'Basi di Dati', stato:'In preparazione', note:'Ripassare le JOIN', dataEsame:'' },
      { id:'p2', idUtente:'u_demo2', materia:'Basi di Dati', stato:'Fase finale', note:'', dataEsame:'2026-07-28' },
      { id:'p3', idUtente:'u_demo3', materia:'Basi di Dati', stato:'Ripetizione', note:'Secondo appello', dataEsame:'' },
      { id:'p4', idUtente:'u_demo2', materia:'Reti di Calcolatori', stato:'Da preparare', note:'', dataEsame:'' }
    ],
    domande: [
      { id:'f1', materia:'Basi di Dati', testo:'Chiede spesso la differenza tra INNER e LEFT JOIN con esempio pratico.', idUtenteAutore:'u_demo1', upvotes:6 },
      { id:'f2', materia:'Basi di Dati', testo:'Bisogna sapere a memoria le forme normali (1NF, 2NF, 3NF) con esempio.', idUtenteAutore:'u_demo2', upvotes:4 },
      { id:'f3', materia:'Reti di Calcolatori', testo:'Domanda ricorrente sul three-way handshake TCP.', idUtenteAutore:'u_demo3', upvotes:2 }
    ]
  };
}

function loadDB(){
  const raw = localStorage.getItem(DB_KEY);
  if(!raw){
    const seeded = seedDatabase();
    localStorage.setItem(DB_KEY, JSON.stringify(seeded));
    return seeded;
  }
  try{ return JSON.parse(raw); }
  catch(e){ const seeded = seedDatabase(); localStorage.setItem(DB_KEY, JSON.stringify(seeded)); return seeded; }
}

function saveDB(db){ localStorage.setItem(DB_KEY, JSON.stringify(db)); }

const DB = {

  resetDemoData(){
    localStorage.removeItem(DB_KEY);
    loadDB();
  },

  // ---------------- Sessione ----------------
  getSession(){
    try{ return JSON.parse(localStorage.getItem(SESSION_KEY)); }catch(e){ return null; }
  },
  setSession(session){ localStorage.setItem(SESSION_KEY, JSON.stringify(session)); },
  clearSession(){ localStorage.removeItem(SESSION_KEY); },

  // ---------------- Utenti ----------------
  findUserByEmail(email){
    const db = loadDB();
    return db.utenti.find(u => u.email.toLowerCase() === email.toLowerCase());
  },
  getUserById(id){
    const db = loadDB();
    return db.utenti.find(u => u.id === id);
  },
  registerUser({ nome, email, password }){
    const db = loadDB();
    if(db.utenti.some(u => u.email.toLowerCase() === email.toLowerCase())){
      throw new Error('Esiste già un account con questa email.');
    }
    const user = { id: uid('u'), nome, email, passwordHash: password, telegram:'', whatsapp:'', privacy:'Pubblico' };
    db.utenti.push(user);
    saveDB(db);
    return user;
  },
  loginWithGoogleMock(nomeSuggerito){
    // In produzione: sostituito da vero OAuth Google (vedi README).
    const db = loadDB();
    const email = (nomeSuggerito || 'utente.google').toLowerCase().replace(/\s+/g,'.') + '@gmail.com';
    let user = db.utenti.find(u => u.email === email);
    if(!user){
      user = { id: uid('u'), nome: nomeSuggerito || 'Utente Google', email, passwordHash:null, telegram:'', whatsapp:'', privacy:'Pubblico' };
      db.utenti.push(user);
      saveDB(db);
    }
    return user;
  },
  updateUser(id, patch){
    const db = loadDB();
    const u = db.utenti.find(x => x.id === id);
    if(!u) return null;
    Object.assign(u, patch);
    saveDB(db);
    return u;
  },

  // ---------------- Catalogo Accademico ----------------
  getCorsi(){
    const db = loadDB();
    return [...new Set(db.catalogo.map(r => r.nomeCorso))];
  },
  getMaterieByCorso(nomeCorso){
    const db = loadDB();
    return [...new Set(db.catalogo.filter(r => r.nomeCorso === nomeCorso).map(r => r.materia))];
  },
  getProfessoriByMateria(nomeCorso, materia){
    const db = loadDB();
    return [...new Set(db.catalogo.filter(r => r.nomeCorso === nomeCorso && r.materia === materia).map(r => r.professore))];
  },

  // ---------------- Piani di Studio ----------------
  getPianiByUser(idUtente){
    const db = loadDB();
    return db.pianiStudio.filter(p => p.idUtente === idUtente);
  },
  addPiano({ idUtente, materia, note, dataEsame }){
    const db = loadDB();
    const esiste = db.pianiStudio.some(p => p.idUtente === idUtente && p.materia === materia);
    if(esiste) throw new Error('Hai già aggiunto questa materia.');
    const piano = { id: uid('p'), idUtente, materia, stato:'Da preparare', note: note||'', dataEsame: dataEsame||'' };
    db.pianiStudio.push(piano);
    saveDB(db);
    return piano;
  },
  updatePiano(id, patch){
    const db = loadDB();
    const p = db.pianiStudio.find(x => x.id === id);
    if(!p) return null;
    Object.assign(p, patch);
    saveDB(db);
    return p;
  },
  deletePiano(id){
    const db = loadDB();
    db.pianiStudio = db.pianiStudio.filter(p => p.id !== id);
    saveDB(db);
  },

  // ---------------- Compagni di studio ----------------
  getCompagniByMateria(materia, idUtenteEscluso){
    const db = loadDB();
    return db.pianiStudio
      .filter(p => p.materia === materia && p.idUtente !== idUtenteEscluso)
      .map(p => {
        const u = db.utenti.find(x => x.id === p.idUtente);
        return u ? { ...u, stato: p.stato, note: p.note } : null;
      })
      .filter(Boolean)
      .filter(u => u.privacy !== 'Privato');
  },

  // ---------------- FAQ ----------------
  getFaqByMateria(materia){
    const db = loadDB();
    return db.domande.filter(f => f.materia === materia).sort((a,b) => b.upvotes - a.upvotes);
  },
  addFaq({ materia, testo, idUtenteAutore }){
    const db = loadDB();
    const faq = { id: uid('f'), materia, testo, idUtenteAutore, upvotes: 0 };
    db.domande.push(faq);
    saveDB(db);
    return faq;
  },
  upvoteFaq(id){
    const db = loadDB();
    const f = db.domande.find(x => x.id === id);
    if(!f) return null;
    f.upvotes += 1;
    saveDB(db);
    return f;
  }
};
