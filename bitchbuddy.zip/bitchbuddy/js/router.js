/* ============================================================
   router.js — instrada le "stanze" del sito in base all'hash
   dell'URL (#/login, #/dashboard, #/materia/ID, #/impostazioni)
   ============================================================ */

const app = document.getElementById('app');

function showToast(msg){
  let t = document.getElementById('toast');
  if(!t){
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => t.classList.remove('show'), 2200);
}

function currentUser(){
  const session = DB.getSession();
  if(!session) return null;
  if(session.guest){
    // L'ospite naviga sui dati dimostrativi di "Giulia Romano" in sola lettura.
    const demoUser = DB.getUserById('u_demo1');
    return { ...demoUser, nome: 'Ospite (demo)', guest:true };
  }
  return DB.getUserById(session.userId) || null;
}

function requireAuth(){
  const session = DB.getSession();
  if(!session){
    location.hash = '#/login';
    return false;
  }
  return true;
}

function renderCorridor(activeKey, materiaLabel){
  const doors = [
    { key:'dashboard', num:1, label:'DASHBOARD', href:'#/dashboard' },
    { key:'materia',   num:2, label: materiaLabel ? ('MATERIA · ' + materiaLabel.toUpperCase()) : 'MATERIA', href:null },
    { key:'impostazioni', num:3, label:'IMPOSTAZIONI', href:'#/impostazioni' }
  ];
  const user = currentUser();
  const doorsHtml = doors.map(d => {
    const cls = 'door' + (d.key === activeKey ? ' active' : '');
    const inner = `<span class="num">${d.num}</span><span>${d.label}</span>`;
    return d.href ? `<a class="${cls}" style="text-decoration:none" href="${d.href}">${inner}</a>` : `<span class="${cls}">${inner}</span>`;
  }).join('');

  return `
    <nav class="corridor">
      <span class="brand">BitchBuddy</span>
      ${doorsHtml}
      <span class="spacer"></span>
      <span class="small-note" style="color:rgba(237,233,224,.7)">${user ? user.nome : ''}</span>
      <button class="exit-btn" id="logoutBtn">Esci</button>
    </nav>`;
}

function attachLogout(){
  const btn = document.getElementById('logoutBtn');
  if(btn) btn.addEventListener('click', () => {
    DB.clearSession();
    location.hash = '#/login';
  });
}

const routes = {
  '#/login': () => renderLogin(),
  '#/dashboard': () => { if(requireAuth()) renderDashboard(); },
  '#/impostazioni': () => { if(requireAuth()) renderImpostazioni(); }
};

function router(){
  const hash = location.hash || '#/login';

  if(hash.startsWith('#/materia/')){
    if(!requireAuth()) return;
    const materiaId = decodeURIComponent(hash.replace('#/materia/', ''));
    renderMateria(materiaId);
    return;
  }

  const handler = routes[hash];
  if(handler) handler();
  else location.hash = '#/login';
}

window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);
