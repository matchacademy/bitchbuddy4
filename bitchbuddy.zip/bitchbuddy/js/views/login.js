/* ============================================================
   views/login.js — Stanza 00 : Ingresso
   Login / Registrazione / Ospite / Google (mock) / Recupero pwd
   ============================================================ */

function renderLogin(){
  let mode = 'login'; // 'login' | 'register' | 'reset'

  function template(){
    return `
    <div class="entry-wrap">
      <div class="entry-card">
        <div class="entry-logo">
          <span class="mark">STANZA 00 · INGRESSO</span>
          <h1>BitchBuddy</h1>
          <p>Il tuo compagno di studio, materia per materia.</p>
        </div>

        <div class="card">
          <div class="mode-switch">
            <button data-mode="login" class="${mode==='login'?'active':''}">Login</button>
            <button data-mode="register" class="${mode==='register'?'active':''}">Registrati</button>
          </div>

          <div id="formArea"></div>

          <div class="divider-or">oppure</div>
          <button class="google-btn" id="googleBtn">
            <span aria-hidden="true">G</span> Continua con Google
          </button>

          <button class="guest-link" id="guestBtn">Entra come Ospite (demo)</button>
        </div>
      </div>
    </div>`;
  }

  function formLogin(){
    return `
      <form id="loginForm">
        <div class="field">
          <label for="loginEmail">Email</label>
          <input id="loginEmail" type="email" required placeholder="nome@email.it" value="giulia@demo.it">
        </div>
        <div class="field">
          <label for="loginPass">Password</label>
          <input id="loginPass" type="password" required placeholder="••••••••" value="demo">
        </div>
        <div id="loginError" class="error-text" style="display:none"></div>
        <button class="btn btn-primary btn-block" type="submit">Accedi</button>
        <button type="button" class="guest-link" id="resetLink" style="margin-top:10px">Password dimenticata?</button>
        <p class="hint" style="margin-top:14px">Demo: giulia@demo.it / marco@demo.it / sara@demo.it — password "demo".</p>
      </form>`;
  }

  function formRegister(){
    return `
      <form id="registerForm">
        <div class="field">
          <label for="regNome">Nome</label>
          <input id="regNome" type="text" required placeholder="Il tuo nome">
        </div>
        <div class="field">
          <label for="regEmail">Email</label>
          <input id="regEmail" type="email" required placeholder="nome@email.it">
        </div>
        <div class="field">
          <label for="regPass">Password</label>
          <input id="regPass" type="password" required minlength="4" placeholder="Almeno 4 caratteri">
        </div>
        <div id="regError" class="error-text" style="display:none"></div>
        <button class="btn btn-primary btn-block" type="submit">Crea account</button>
        <p class="hint" style="margin-top:14px">In produzione qui parte una vera email di verifica (vedi README, sezione backend).</p>
      </form>`;
  }

  function formReset(){
    return `
      <form id="resetForm">
        <div class="field">
          <label for="resetEmail">Email del tuo account</label>
          <input id="resetEmail" type="email" required placeholder="nome@email.it">
        </div>
        <button class="btn btn-primary btn-block" type="submit">Invia link di ripristino</button>
        <button type="button" class="guest-link" id="backToLogin">Torna al login</button>
      </form>`;
  }

  function renderFormArea(){
    const area = document.getElementById('formArea');
    if(mode === 'login') area.innerHTML = formLogin();
    else if(mode === 'register') area.innerHTML = formRegister();
    else area.innerHTML = formReset();
    bindFormEvents();
  }

  function bindFormEvents(){
    const loginForm = document.getElementById('loginForm');
    if(loginForm) loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value.trim();
      const pass = document.getElementById('loginPass').value;
      const user = DB.findUserByEmail(email);
      const errBox = document.getElementById('loginError');
      if(!user || user.passwordHash !== pass){
        errBox.textContent = 'Email o password non corrette.';
        errBox.style.display = 'block';
        return;
      }
      DB.setSession({ userId: user.id });
      location.hash = '#/dashboard';
    });

    const registerForm = document.getElementById('registerForm');
    if(registerForm) registerForm.addEventListener('submit', e => {
      e.preventDefault();
      const nome = document.getElementById('regNome').value.trim();
      const email = document.getElementById('regEmail').value.trim();
      const pass = document.getElementById('regPass').value;
      const errBox = document.getElementById('regError');
      try{
        const user = DB.registerUser({ nome, email, password: pass });
        DB.setSession({ userId: user.id });
        showToast('Account creato. (In produzione: email di verifica inviata)');
        location.hash = '#/dashboard';
      }catch(err){
        errBox.textContent = err.message;
        errBox.style.display = 'block';
      }
    });

    const resetForm = document.getElementById('resetForm');
    if(resetForm) resetForm.addEventListener('submit', e => {
      e.preventDefault();
      showToast('Se l\'indirizzo esiste, riceverai un\'email di ripristino.');
      mode = 'login';
      renderFormArea();
    });

    const resetLink = document.getElementById('resetLink');
    if(resetLink) resetLink.addEventListener('click', () => { mode = 'reset'; renderFormArea(); });

    const backToLogin = document.getElementById('backToLogin');
    if(backToLogin) backToLogin.addEventListener('click', () => { mode = 'login'; renderFormArea(); });
  }

  app.innerHTML = template();
  renderFormArea();

  document.querySelectorAll('.mode-switch button').forEach(btn => {
    btn.addEventListener('click', () => {
      mode = btn.dataset.mode;
      document.querySelectorAll('.mode-switch button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderFormArea();
    });
  });

  document.getElementById('googleBtn').addEventListener('click', () => {
    // MOCK: in produzione questo bottone avvia il vero OAuth Google.
    // Vedi README.md → "Attivare il login reale con Google".
    const user = DB.loginWithGoogleMock('Utente Demo');
    DB.setSession({ userId: user.id });
    showToast('Accesso con Google simulato per la demo.');
    location.hash = '#/dashboard';
  });

  document.getElementById('guestBtn').addEventListener('click', () => {
    DB.setSession({ guest: true });
    location.hash = '#/dashboard';
  });
}
