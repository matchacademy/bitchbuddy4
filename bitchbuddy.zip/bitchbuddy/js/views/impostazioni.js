/* ============================================================
   views/impostazioni.js — Stanza 03 : Impostazioni
   Profilo, contatti (Telegram/WhatsApp), privacy, database demo
   ============================================================ */

function renderImpostazioni(){
  const user = currentUser();
  let tab = 'profilo'; // 'profilo' | 'personalizzazione'

  function template(){
    return `
      ${renderCorridor('impostazioni')}
      <div class="room">
        <span class="room-plaque"><span class="dot"></span>STANZA 03 · IMPOSTAZIONI</span>
        <h1>Impostazioni</h1>
        <p>Gestisci il tuo profilo, i canali di contatto e le preferenze del sito.</p>

        <div class="settings-layout">
          <nav class="settings-nav">
            <button data-tab="profilo" class="${tab==='profilo'?'active':''}">Profilo &amp; contatti</button>
            <button data-tab="personalizzazione" class="${tab==='personalizzazione'?'active':''}">Personalizzazione</button>
          </nav>
          <div id="settingsContent"></div>
        </div>
      </div>`;
  }

  function profiloTemplate(){
    return `
      <div class="card">
        <h3>Dati personali</h3>
        <form id="profiloForm">
          <div class="field">
            <label for="pNome">Nome</label>
            <input id="pNome" type="text" value="${user.nome}" ${user.guest ? 'disabled' : ''}>
          </div>
          <div class="field">
            <label for="pEmail">Email</label>
            <input id="pEmail" type="email" value="${user.email || ''}" disabled>
            <div class="hint">L'email non è modificabile in questa demo.</div>
          </div>
          <div class="field">
            <label for="pTelegram">Nome utente Telegram</label>
            <input id="pTelegram" type="text" value="${user.telegram || ''}" placeholder="@tuonome" ${user.guest ? 'disabled' : ''}>
          </div>
          <div class="field">
            <label for="pWhatsapp">Numero WhatsApp</label>
            <input id="pWhatsapp" type="text" value="${user.whatsapp || ''}" placeholder="39333xxxxxxx" ${user.guest ? 'disabled' : ''}>
          </div>
          <div class="field">
            <label for="pPrivacy">Visibilità del profilo</label>
            <select id="pPrivacy" ${user.guest ? 'disabled' : ''}>
              <option value="Pubblico" ${user.privacy==='Pubblico'?'selected':''}>Pubblico — visibile ai compagni di corso</option>
              <option value="Privato" ${user.privacy==='Privato'?'selected':''}>Privato — nascosto dalle liste compagni</option>
            </select>
            <div class="hint">Riduci richieste indesiderate impostando il profilo su Privato.</div>
          </div>
          <button class="btn btn-primary" type="submit" ${user.guest ? 'disabled' : ''}>Salva modifiche</button>
        </form>
      </div>`;
  }

  function personalizzazioneTemplate(){
    return `
      <div class="card">
        <h3>Notifiche</h3>
        <div class="field">
          <label><input type="checkbox" checked ${user.guest ? 'disabled' : ''}> Avvisami quando un compagno mi contatta</label>
        </div>
        <div class="field">
          <label><input type="checkbox" checked ${user.guest ? 'disabled' : ''}> Avvisami quando c'è una nuova domanda FAQ nelle mie materie</label>
        </div>
      </div>
      <div class="card" style="margin-top:20px">
        <h3>Gestione database (demo)</h3>
        <p>I dati di questa demo vivono nel localStorage del browser. Puoi riportarli allo stato iniziale in qualsiasi momento.</p>
        <button class="btn btn-outline" id="resetBtn">Ripristina dati demo</button>
      </div>`;
  }

  function renderTab(){
    document.getElementById('settingsContent').innerHTML = tab === 'profilo' ? profiloTemplate() : personalizzazioneTemplate();
    bindTabEvents();
  }

  function bindTabEvents(){
    const form = document.getElementById('profiloForm');
    if(form) form.addEventListener('submit', e => {
      e.preventDefault();
      if(user.guest) return;
      DB.updateUser(user.id, {
        nome: document.getElementById('pNome').value.trim(),
        telegram: document.getElementById('pTelegram').value.trim(),
        whatsapp: document.getElementById('pWhatsapp').value.trim(),
        privacy: document.getElementById('pPrivacy').value
      });
      showToast('Profilo aggiornato.');
    });

    const resetBtn = document.getElementById('resetBtn');
    if(resetBtn) resetBtn.addEventListener('click', () => {
      if(confirm('Questo cancellerà tutte le modifiche fatte nella demo. Continuare?')){
        DB.resetDemoData();
        showToast('Dati demo ripristinati.');
      }
    });
  }

  app.innerHTML = template();
  attachLogout();
  renderTab();

  document.querySelectorAll('.settings-nav button').forEach(btn => {
    btn.addEventListener('click', () => {
      tab = btn.dataset.tab;
      document.querySelectorAll('.settings-nav button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderTab();
    });
  });
}
