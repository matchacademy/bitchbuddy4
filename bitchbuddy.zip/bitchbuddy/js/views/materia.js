/* ============================================================
   views/materia.js — Stanza 02 : Materia
   Compagni di studio + Domande frequenti (FAQ) + chat interna
   ============================================================ */

function renderMateria(materia){
  const user = currentUser();
  let activeTab = 'compagni'; // 'compagni' | 'faq'
  let filtroStato = '';
  let chatAperta = null; // id utente con cui si sta "chattando"

  function template(){
    return `
      ${renderCorridor('materia', materia)}
      <div class="room">
        <span class="room-plaque"><span class="dot"></span>STANZA 02 · ${materia.toUpperCase()}</span>
        <div class="row-between">
          <h1>${materia}</h1>
          <button class="btn btn-outline btn-sm" id="shareBtn">Condividi su WhatsApp</button>
        </div>
        <p>Trova compagni che stanno preparando questo esame e consulta le domande più frequenti.</p>

        <div class="tab-row">
          <button class="tab-btn ${activeTab==='compagni'?'active':''}" data-tab="compagni">Cerca compagni di studio</button>
          <button class="tab-btn ${activeTab==='faq'?'active':''}" data-tab="faq">Domande frequenti</button>
        </div>

        <div id="tabContent"></div>
      </div>`;
  }

  function compagniTemplate(){
    let compagni = DB.getCompagniByMateria(materia, user.id);
    if(filtroStato) compagni = compagni.filter(c => c.stato === filtroStato);

    return `
      <div class="card">
        <div class="filter-row">
          <select id="filtroStato">
            <option value="">Tutte le fasi</option>
            ${STATI.map(s => `<option value="${s}" ${s===filtroStato?'selected':''}>${s}</option>`).join('')}
          </select>
        </div>

        ${compagni.length ? compagni.map(c => `
          <div class="buddy-card">
            <div>
              <div class="buddy-name">${c.nome}</div>
              <div class="subject-meta">${c.stato}${c.note ? ' · ' + c.note : ''}</div>
              <div class="buddy-contacts">
                ${c.telegram ? `<span class="tag">Telegram ${c.telegram}</span>` : ''}
                ${c.whatsapp ? `<span class="tag">WhatsApp</span>` : ''}
              </div>
            </div>
            <button class="btn btn-brass btn-sm contactBtn" data-id="${c.id}" data-nome="${c.nome}" ${user.guest ? 'disabled title="Registrati per contattare i compagni"' : ''}>Contatta</button>
          </div>
        `).join('') : `<div class="empty-state">Nessun compagno trovato per questo filtro.</div>`}
      </div>

      <div class="card" id="chatCard" style="display:none; margin-top:20px">
        <h3 id="chatTitle">Chat</h3>
        <div class="chat-window" id="chatWindow"></div>
        <div class="chat-input-row">
          <input type="text" id="chatInput" placeholder="Scrivi un messaggio…">
          <button class="btn btn-primary" id="chatSendBtn">Invia</button>
        </div>
        <p class="small-note" style="margin-top:8px">Chat interna dimostrativa — i messaggi non vengono salvati. In produzione qui si collega Firebase Realtime/Firestore (vedi README).</p>
      </div>`;
  }

  function faqTemplate(){
    const faq = DB.getFaqByMateria(materia);
    return `
      <div class="card">
        <h3>Fai una domanda</h3>
        <form id="faqForm">
          <div class="field">
            <textarea id="faqTesto" placeholder="Scrivi una domanda frequente su questo esame…" required ${user.guest ? 'disabled' : ''}></textarea>
          </div>
          <button class="btn btn-brass" type="submit" ${user.guest ? 'disabled title="Registrati per pubblicare una domanda"' : ''}>Pubblica domanda</button>
        </form>
      </div>
      <div class="card" style="margin-top:20px">
        ${faq.length ? faq.map(f => `
          <div class="faq-item">
            <div class="faq-top">
              <p style="margin:0">${f.testo}</p>
              <button class="upvote-btn upvoteBtn" data-id="${f.id}">▲ ${f.upvotes}</button>
            </div>
            <div class="subject-meta">di ${(DB.getUserById(f.idUtenteAutore) || {}).nome || 'utente'}</div>
          </div>
        `).join('') : `<div class="empty-state">Nessuna domanda ancora. Sii il primo a scriverne una.</div>`}
      </div>`;
  }

  function renderTab(){
    document.getElementById('tabContent').innerHTML = activeTab === 'compagni' ? compagniTemplate() : faqTemplate();
    bindTabEvents();
  }

  function bindTabEvents(){
    if(activeTab === 'compagni'){
      const filtro = document.getElementById('filtroStato');
      if(filtro) filtro.addEventListener('change', () => { filtroStato = filtro.value; renderTab(); });

      document.querySelectorAll('.contactBtn').forEach(btn => {
        btn.addEventListener('click', () => {
          chatAperta = { id: btn.dataset.id, nome: btn.dataset.nome };
          openChat();
        });
      });
    } else {
      const faqForm = document.getElementById('faqForm');
      if(faqForm) faqForm.addEventListener('submit', e => {
        e.preventDefault();
        const testo = document.getElementById('faqTesto').value.trim();
        if(!testo) return;
        DB.addFaq({ materia, testo, idUtenteAutore: user.id });
        showToast('Domanda pubblicata.');
        renderTab();
      });

      document.querySelectorAll('.upvoteBtn').forEach(btn => {
        btn.addEventListener('click', () => {
          DB.upvoteFaq(btn.dataset.id);
          renderTab();
        });
      });
    }
  }

  function openChat(){
    const card = document.getElementById('chatCard');
    card.style.display = 'block';
    document.getElementById('chatTitle').textContent = 'Chat con ' + chatAperta.nome;
    document.getElementById('chatWindow').innerHTML = `
      <div class="chat-msg"><span class="who">${chatAperta.nome}</span>Ciao! Anche tu prepari questo esame?</div>`;
    card.scrollIntoView({ behavior:'smooth', block:'center' });

    document.getElementById('chatSendBtn').onclick = () => sendMsg();
    document.getElementById('chatInput').onkeydown = (e) => { if(e.key === 'Enter') sendMsg(); };
  }

  function sendMsg(){
    const input = document.getElementById('chatInput');
    const val = input.value.trim();
    if(!val) return;
    const win = document.getElementById('chatWindow');
    win.innerHTML += `<div class="chat-msg"><span class="who">Tu</span>${val}</div>`;
    input.value = '';
    win.scrollTop = win.scrollHeight;
  }

  app.innerHTML = template();
  attachLogout();
  renderTab();

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => { activeTab = btn.dataset.tab; renderTab(); document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); });
  });

  document.getElementById('shareBtn').addEventListener('click', () => {
    const testo = `Ciao! Sto preparando ${materia} su BitchBuddy, unisciti anche tu: ${location.origin}${location.pathname}#/materia/${encodeURIComponent(materia)}`;
    window.open('https://wa.me/?text=' + encodeURIComponent(testo), '_blank');
  });
}
