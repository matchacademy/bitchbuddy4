/* ============================================================
   views/dashboard.js — Stanza 01 : Dashboard
   Pannello inserimento a cascata + lista materie con stato/nota
   ============================================================ */

const STATI = ['Da preparare', 'In preparazione', 'Ripetizione', 'Fase finale'];
const STATO_PCT = { 'Da preparare':10, 'In preparazione':45, 'Ripetizione':70, 'Fase finale':90 };
const STATO_CLASS = { 'Da preparare':'s0', 'In preparazione':'s1', 'Ripetizione':'s2', 'Fase finale':'s3' };

function renderDashboard(){
  const user = currentUser();

  function template(){
    const piani = DB.getPianiByUser(user.id).sort((a,b) => (a.dataEsame||'9999').localeCompare(b.dataEsame||'9999'));

    return `
      ${renderCorridor('dashboard')}
      <div class="room">
        <span class="room-plaque"><span class="dot"></span>STANZA 01 · DASHBOARD</span>
        <h1>Le tue materie</h1>
        <p>Aggiungi un corso, scegli la materia e il professore, poi tieni traccia dello stato di preparazione.</p>

        ${user.guest ? `<div class="card" style="border-color:var(--brass); margin-bottom:20px"><p style="margin:0"><strong>Modalità Ospite:</strong> stai esplorando dati dimostrativi. Registrati per salvare i tuoi progressi reali.</p></div>` : ''}

        <div class="card">
          <h3>Aggiungi materia</h3>
          <form id="addSubjectForm">
            <div class="cascade-row">
              <div class="field">
                <label for="selCorso">Corso</label>
                <select id="selCorso" required>
                  <option value="">Seleziona corso…</option>
                  ${DB.getCorsi().map(c => `<option value="${c}">${c}</option>`).join('')}
                </select>
              </div>
              <div class="field">
                <label for="selMateria">Materia</label>
                <select id="selMateria" required disabled>
                  <option value="">Prima scegli il corso…</option>
                </select>
              </div>
              <div class="field">
                <label for="selProf">Professore</label>
                <select id="selProf" required disabled>
                  <option value="">Prima scegli la materia…</option>
                </select>
              </div>
            </div>
            <div class="subject-form-extra">
              <div class="field">
                <label for="noteInput">Note (facoltativo)</label>
                <input id="noteInput" type="text" placeholder="Es. ripassare capitolo 3">
              </div>
              <div class="field">
                <label for="dataEsame">Data esame (facoltativo)</label>
                <input id="dataEsame" type="date">
              </div>
            </div>
            <div id="addSubjectError" class="error-text" style="display:none"></div>
            <button class="btn btn-brass" type="submit">+ Aggiungi materia</button>
          </form>
        </div>

        <div class="row-between" style="margin-top:28px">
          <h2 style="margin:0">Le materie aggiunte</h2>
          <span class="small-note">ordinate per data esame più vicina</span>
        </div>

        <div class="subject-list" id="subjectList">
          ${piani.length ? piani.map(subjectItemTemplate).join('') : `<div class="empty-state">Non hai ancora aggiunto nessuna materia. Usa il modulo qui sopra.</div>`}
        </div>
      </div>`;
  }

  function subjectItemTemplate(p){
    const pct = STATO_PCT[p.stato] || 10;
    return `
      <div class="subject-item" data-id="${p.id}">
        <div class="top-row">
          <div>
            <h3 data-goto="${p.materia}">${p.materia}</h3>
            ${p.dataEsame ? `<div class="subject-meta">Esame: ${p.dataEsame}</div>` : ''}
            ${p.note ? `<div class="subject-meta">Nota: ${p.note}</div>` : ''}
          </div>
          <span class="status-pill ${STATO_CLASS[p.stato]}">${p.stato}</span>
        </div>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
        <div class="item-actions">
          <select class="statoSelect" data-id="${p.id}" ${user.guest ? 'disabled' : ''}>
            ${STATI.map(s => `<option value="${s}" ${s===p.stato?'selected':''}>${s}</option>`).join('')}
          </select>
          ${p.stato === 'Fase finale' && p.dataEsame ? `<button class="btn btn-ghost btn-sm calBtn" data-id="${p.id}">+ Google Calendar</button>` : ''}
          <button class="btn btn-outline btn-sm openBtn" data-materia="${p.materia}">Apri stanza materia</button>
          <button class="btn btn-danger btn-sm delBtn" data-id="${p.id}" ${user.guest ? 'disabled' : ''}>Elimina</button>
        </div>
      </div>`;
  }

  function refreshList(){
    const piani = DB.getPianiByUser(user.id).sort((a,b) => (a.dataEsame||'9999').localeCompare(b.dataEsame||'9999'));
    document.getElementById('subjectList').innerHTML = piani.length ? piani.map(subjectItemTemplate).join('') : `<div class="empty-state">Non hai ancora aggiunto nessuna materia. Usa il modulo qui sopra.</div>`;
    bindListEvents();
  }

  function bindListEvents(){
    document.querySelectorAll('[data-goto]').forEach(el => {
      el.addEventListener('click', () => location.hash = '#/materia/' + encodeURIComponent(el.dataset.goto));
    });
    document.querySelectorAll('.openBtn').forEach(el => {
      el.addEventListener('click', () => location.hash = '#/materia/' + encodeURIComponent(el.dataset.materia));
    });
    document.querySelectorAll('.statoSelect').forEach(el => {
      el.addEventListener('change', () => {
        DB.updatePiano(el.dataset.id, { stato: el.value });
        refreshList();
      });
    });
    document.querySelectorAll('.delBtn').forEach(el => {
      el.addEventListener('click', () => {
        if(confirm('Eliminare questa materia dal tuo piano di studio?')){
          DB.deletePiano(el.dataset.id);
          refreshList();
        }
      });
    });
    document.querySelectorAll('.calBtn').forEach(el => {
      el.addEventListener('click', () => {
        const piano = DB.getPianiByUser(user.id).find(p => p.id === el.dataset.id);
        if(!piano || !piano.dataEsame) return;
        const dateStr = piano.dataEsame.replace(/-/g, '');
        const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent('Esame: ' + piano.materia)}&dates=${dateStr}/${dateStr}`;
        window.open(url, '_blank');
      });
    });
  }

  function bindFormEvents(){
    const selCorso = document.getElementById('selCorso');
    const selMateria = document.getElementById('selMateria');
    const selProf = document.getElementById('selProf');

    selCorso.addEventListener('change', () => {
      const materie = DB.getMaterieByCorso(selCorso.value);
      selMateria.innerHTML = materie.length
        ? `<option value="">Seleziona materia…</option>` + materie.map(m => `<option value="${m}">${m}</option>`).join('')
        : `<option value="">Nessuna materia disponibile</option>`;
      selMateria.disabled = !selCorso.value;
      selProf.innerHTML = `<option value="">Prima scegli la materia…</option>`;
      selProf.disabled = true;
    });

    selMateria.addEventListener('change', () => {
      const profs = DB.getProfessoriByMateria(selCorso.value, selMateria.value);
      selProf.innerHTML = profs.length
        ? `<option value="">Seleziona professore…</option>` + profs.map(p => `<option value="${p}">${p}</option>`).join('')
        : `<option value="">Nessun professore disponibile</option>`;
      selProf.disabled = !selMateria.value;
    });

    document.getElementById('addSubjectForm').addEventListener('submit', e => {
      e.preventDefault();
      const errBox = document.getElementById('addSubjectError');
      if(user.guest){
        errBox.textContent = 'Registrati per salvare le tue materie personali.';
        errBox.style.display = 'block';
        return;
      }
      try{
        DB.addPiano({
          idUtente: user.id,
          materia: selMateria.value,
          note: document.getElementById('noteInput').value.trim(),
          dataEsame: document.getElementById('dataEsame').value
        });
        e.target.reset();
        selMateria.disabled = true; selProf.disabled = true;
        showToast('Materia aggiunta al tuo piano di studio.');
        refreshList();
      }catch(err){
        errBox.textContent = err.message;
        errBox.style.display = 'block';
      }
    });
  }

  app.innerHTML = template();
  attachLogout();
  bindFormEvents();
  bindListEvents();
}
