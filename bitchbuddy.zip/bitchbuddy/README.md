# BitchBuddy — README

Guida completa per far funzionare il sito, sia in versione demo che con il backend reale descritto nel documento originale (Google Sheets + Google Apps Script).

---

## 1. Cosa contiene questo pacchetto

```
bitchbuddy/
├── index.html              → l'unica pagina del sito (tipo "app")
├── css/
│   └── style.css           → tutto lo stile grafico
├── js/
│   ├── db.js                → "database" della demo (localStorage)
│   ├── router.js             → naviga tra le sezioni del sito
│   └── views/
│       ├── login.js         → Stanza 00: Login / Registrati / Ospite
│       ├── dashboard.js      → Stanza 01: Dashboard e menu a cascata
│       ├── materia.js        → Stanza 02: Compagni di studio + FAQ
│       └── impostazioni.js   → Stanza 03: Profilo, contatti, privacy
├── backend-gas/              → backend REALE pronto da incollare in
│   │                           Google Apps Script (facoltativo, vedi § 4)
│   ├── Code.gs               → punto di ingresso (doGet/doPost)
│   ├── Utenti.gs
│   ├── Catalogo.gs
│   ├── PianiStudio.gs
│   └── FAQ.gs
└── README.md                 → questo file
```

Il sito è già **completamente funzionante così com'è**, perché usa il
localStorage del browser al posto di un vero database: puoi
registrarti, aggiungere materie, cercare compagni, scrivere FAQ, ecc.
Quando vorrai renderlo "vero" (dati condivisi tra utenti reali), segui
la sezione 4.

---

## 2. Come aprirlo subito (nessuna installazione)

**Opzione A — doppio click**
Apri semplicemente il file `index.html` con il browser. Funziona, ma
alcuni browser limitano il localStorage sui file aperti con `file://`:
se noti che i dati non si salvano, usa l'Opzione B.

**Opzione B — piccolo server locale (consigliata)**
Se hai Python installato:
```bash
cd bitchbuddy
python3 -m http.server 8000
```
poi apri il browser su `http://localhost:8000`.

Se hai Node.js:
```bash
npx serve bitchbuddy
```

**Account demo già pronti** (email / password):
- `giulia@demo.it` / `demo`
- `marco@demo.it` / `demo`
- `sara@demo.it` / `demo`

Oppure usa il pulsante **"Entra come Ospite"** per esplorare il sito
già popolato di dati fittizi, senza registrarti (proprio come chiesto
nel documento originale).

---

## 3. Pubblicare il sito online (accessibile da un link)

Il sito è fatto solo di file statici (HTML/CSS/JS), quindi puoi
pubblicarlo gratis in pochi minuti:

**GitHub Pages**
1. Crea una repository su GitHub e carica il contenuto della cartella `bitchbuddy/`.
2. Vai su *Settings → Pages*, scegli il branch `main` e la cartella `/root`.
3. Dopo un minuto il sito sarà online su `https://tuonome.github.io/nome-repo/`.

**Netlify / Vercel**
1. Trascina la cartella `bitchbuddy/` nella dashboard di Netlify ("Deploy manually").
2. Ottieni subito un link pubblico.

⚠️ Nota importante: finché usi il `db.js` con localStorage, **ogni
visitatore vede solo i propri dati salvati nel proprio browser** — i
dati non sono condivisi tra utenti diversi. Per avere un sito dove gli
studenti vedono davvero gli stessi compagni e le stesse FAQ, serve il
backend reale della sezione 4.

---

## 4. Collegare il backend reale (Google Sheets + Google Apps Script)

Questa è l'architettura descritta nel documento originale. I file
pronti sono nella cartella `backend-gas/`.

### Passo 1 — Crea il Google Sheet
1. Crea un nuovo Google Sheet.
2. Crea 4 schede (fogli) con **questi nomi esatti** e queste colonne nella prima riga:

**Scheda "Utenti"**
| ID_Utente | Nome | Email | Password_Hash | Telegram_Username | WhatsApp_Link | Privacy_Status |
|---|---|---|---|---|---|---|

**Scheda "Catalogo_Accademico"**
| ID_Corso | Nome_Corso | Materia | Professore |
|---|---|---|---|

**Scheda "Piani_Studio"**
| ID_Record | ID_Utente | Materia | Stato | Note | Data_Esame |
|---|---|---|---|---|---|

**Scheda "Domande_FAQ"**
| ID_Domanda | Materia | Testo_Domanda | ID_Utente_Autore | Upvotes |
|---|---|---|---|---|

3. Copia l'ID dello Sheet dalla barra degli indirizzi (la stringa lunga tra `/d/` e `/edit`).

### Passo 2 — Crea il progetto Apps Script
1. Nel tuo Google Sheet vai su *Estensioni → Apps Script*.
2. Cancella il codice di default e crea 5 file **con lo stesso nome** di quelli in `backend-gas/`: `Code.gs`, `Utenti.gs`, `Catalogo.gs`, `PianiStudio.gs`, `FAQ.gs`.
3. Copia il contenuto di ogni file dalla cartella `backend-gas/` nel file corrispondente.
4. In `Code.gs`, sostituisci `INCOLLA_QUI_ID_DEL_TUO_GOOGLE_SHEET` con l'ID copiato al Passo 1.

### Passo 3 — Pubblica come Web App
1. Clicca su *Distribuisci → Nuova implementazione*.
2. Tipo: *Applicazione web*.
3. "Chi ha accesso": scegli **"Chiunque"** (necessario perché il sito lo chiami dall'esterno).
4. Clicca *Distribuisci* e autorizza i permessi richiesti (accesso al tuo Sheet).
5. Copia l'URL della Web App che ti viene mostrato (finisce con `/exec`).

### Passo 4 — Collega il frontend al backend
Nel file `js/db.js`, l'intero oggetto `DB` va sostituito con delle
chiamate `fetch()` verso l'URL ottenuto al Passo 3, ad esempio:

```javascript
const API_URL = 'https://script.google.com/macros/s/IL_TUO_ID/exec';

async function apiGet(action, params = {}){
  const query = new URLSearchParams({ action, ...params }).toString();
  const res = await fetch(`${API_URL}?${query}`);
  return res.json();
}

async function apiPost(action, payload = {}){
  const res = await fetch(API_URL, {
    method: 'POST',
    body: JSON.stringify({ action, ...payload })
  });
  return res.json();
}
```

Ogni funzione dentro `DB` (es. `getCorsi`, `addPiano`, `getFaqByMateria`)
va resa `async` e va sostituito il codice che leggeva `localStorage`
con la corrispondente chiamata `apiGet`/`apiPost`. I nomi delle azioni
(`getCatalogo`, `addPiano`, `upvoteFaq`, ecc.) sono già quelli gestiti
da `Code.gs`, quindi non serve inventare nulla: basta collegare i fili.
Le view (`dashboard.js`, `materia.js`, ecc.) non vanno toccate.

### Passo 5 — Attivare il login reale con Google
Nella demo il pulsante "Continua con Google" è **simulato** (crea un
utente finto senza vera autenticazione). Per renderlo reale, la strada
più semplice quando il backend è Apps Script è:
1. In Google Cloud Console, crea un progetto e una schermata di
   consenso OAuth (*OAuth consent screen*).
2. Crea un *OAuth Client ID* di tipo "Applicazione web".
3. Nel frontend, sostituisci il click su "Continua con Google" con la
   libreria ufficiale *Google Identity Services* (`accounts.google.com/gsi/client`),
   che restituisce un token con l'email dell'utente.
4. Manda quel token al tuo `Code.gs`: nel backend puoi verificarlo, o
   più semplicemente usare l'email restituita per cercare/creare
   l'utente nella scheda "Utenti" (stessa logica già presente in
   `Utenti_login`, ma senza controllo password).

Se invece decidi di **non** creare pagine registrazione custom, puoi
sfruttare il fatto che Apps Script conosce già l'utente Google loggato
con `Session.getActiveUser().getEmail()` — utile se pubblichi il sito
direttamente come "Web App" di Apps Script invece che come pagina HTML
esterna.

---

## 5. Funzionalità già presenti e dove trovarle nel codice

| Funzionalità richiesta | File | Note |
|---|---|---|
| Login / Registrati / Ospite | `js/views/login.js` | Ospite = dati demo di sola esplorazione |
| Recupero password | `js/views/login.js` | form "Password dimenticata" (mock, da collegare a `MailApp` lato Apps Script) |
| Menu a cascata Corso→Materia→Professore | `js/views/dashboard.js` | legge da `DB.getCorsi/getMaterieByCorso/getProfessoriByMateria` |
| Materie salvate permanentemente | `js/db.js` (`pianiStudio`) | persistono tra le sessioni via localStorage / Sheet |
| Stato materia + barra di progresso | `js/views/dashboard.js` | mappa `STATO_PCT` per la percentuale |
| Ordinamento per data esame più vicina | `js/views/dashboard.js` | `.sort()` sulla lista |
| Pulsante "Aggiungi a Google Calendar" | `js/views/dashboard.js` | link diretto `calendar.google.com/render`, appare solo in "Fase finale" con data impostata |
| Stanza materia: compagni + FAQ | `js/views/materia.js` | due tab |
| Filtro compagni per fase di preparazione | `js/views/materia.js` | select `filtroStato` |
| Condivisione su WhatsApp | `js/views/materia.js` | `wa.me/?text=` con link diretto alla materia |
| Blocco interazioni per non registrati | tutte le view | i pulsanti "Contatta"/"Pubblica domanda"/"Aggiungi materia" sono disabilitati in modalità Ospite |
| Chat interna (demo) | `js/views/materia.js` | attualmente locale/finta; in produzione da collegare a Firebase (vedi sotto) |
| Profilo + contatti Telegram/WhatsApp | `js/views/impostazioni.js` | |
| Privacy profilo (Pubblico/Privato) | `js/views/impostazioni.js` + `js/db.js` | i profili "Privato" spariscono dalla lista compagni |
| Menu laterale impostazioni | `js/views/impostazioni.js` | tab "Profilo" / "Personalizzazione" |

---

## 6. Chat in tempo reale tra compagni (oltre la demo)

La chat interna nella Stanza Materia è, per ora, solo dimostrativa (i
messaggi non vengono salvati da nessuna parte). Come indicato anche
nel documento originale, per una chat vera tra studenti la soluzione
più semplice è **Firebase**:
1. Crea un progetto Firebase gratuito.
2. Attiva *Cloud Firestore* (o *Realtime Database*).
3. Aggiungi l'SDK Firebase via CDN nell'`index.html`.
4. Sostituisci `sendMsg()` e l'apertura chat in `js/views/materia.js`
   con letture/scritture su una collezione tipo `chat/{materia}/{coppiaUtenti}`.

In alternativa più rapida, come suggerito nel documento, puoi evitare
del tutto la chat interna e mettere sul profilo di ogni utente un
bottone diretto a Telegram (`t.me/username`) o WhatsApp (`wa.me/numero`)
— è già quello che fa la sezione "Contatti" in Impostazioni.

---

## 7. Problemi comuni

- **"I dati spariscono ogni volta che ricarico"** → stai aprendo il file
  con doppio click (`file://`); usa un server locale (§ 2, Opzione B).
- **"Ho premuto Ripristina dati demo e ho perso le modifiche"** → è il
  comportamento previsto del pulsante in Impostazioni → Personalizzazione:
  riporta il localStorage ai dati di esempio iniziali.
- **"Il backend Apps Script risponde con errore di permessi"** → in
  *Distribuisci → Nuova implementazione* controlla che "Chi ha accesso"
  sia impostato su "Chiunque", altrimenti il `fetch()` dal sito viene
  bloccato.
- **"Le select a cascata restano disabilitate"** → è normale finché
  non scegli il campo precedente (Corso → poi Materia → poi Professore).

---

Buono studio! 🎓
